import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './valentine-styles.css';

export default function ValentineApp() {
  const [noButtonStyle, setNoButtonStyle] = useState({});
  const [noClickCount, setNoClickCount] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [answered, setAnswered] = useState(false);

  const messages = [
    "Czy zostaniesz moją Walentynką? 💝",
    "Jesteś pewna? 🥺",
    "Naprawdę? 😢",
    "Może jednak tak? 💕",
    "Proszę? 🙏",
    "Ostatnia szansa! ❤️"
  ];

  const moveNoButton = () => {
    const newCount = noClickCount + 1;
    setNoClickCount(newCount);
    
    const randomX = Math.random() * 300 - 150;
    const randomY = Math.random() * 300 - 150;
    
    setNoButtonStyle({
      transform: `translate(${randomX}px, ${randomY}px)`,
      transition: 'transform 0.3s ease'
    });
  };

  const handleYes = () => {
    setAnswered(true);
    setShowConfetti(true);
  };

  const currentMessage = messages[Math.min(noClickCount, messages.length - 1)];

  if (answered) {
    return (
      <div className="success-screen d-flex align-items-center justify-content-center min-vh-100 p-4 overflow-hidden">
        {showConfetti && (
          <div className="confetti-container">
            {[...Array(50)].map((_, i) => (
              <div
                key={i}
                className="confetti"
                style={{
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`,
                  backgroundColor: ['#ff69b4', '#ff1493', '#ff6b9d', '#ffc0cb', '#ff4500'][Math.floor(Math.random() * 5)]
                }}
              />
            ))}
          </div>
        )}
        
        <div className="text-center animate-bounce-in">
          <div className="display-1 mb-4 animate-pulse">💖</div>
          <h1 className="display-2 fw-bold text-white mb-4 text-shadow">
            Kocham Cię! 
          </h1>
          <p className="display-6 text-white mb-5 text-shadow-sm">
            Wiedziałem, że powiesz TAK! 🥰
          </p>
          <div className="d-flex gap-4 justify-content-center fs-1 animate-float">
            <span className="animate-heart">❤️</span>
            <span className="animate-heart" style={{animationDelay: '0.2s'}}>💕</span>
            <span className="animate-heart" style={{animationDelay: '0.4s'}}>💝</span>
            <span className="animate-heart" style={{animationDelay: '0.6s'}}>💖</span>
            <span className="animate-heart" style={{animationDelay: '0.8s'}}>💗</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="main-screen d-flex align-items-center justify-content-center min-vh-100 p-4">
      <div className="card card-main shadow-lg p-5 text-center">
        <div className="card-body">
          <div className="display-1 mb-4 animate-pulse">💝</div>
          
          <h1 className="display-4 fw-bold text-dark mb-3">
            {currentMessage}
          </h1>
          
          <p className="lead text-muted mb-5 fst-italic">
            Będzie mi bardzo miło spędzić z Tobą Walentynki! 🌹
          </p>
          
          <div className="d-flex gap-4 justify-content-center align-items-center flex-wrap mb-4">
            <button
              onClick={handleYes}
              className="btn btn-yes btn-lg rounded-pill px-5 py-3 fw-bold shadow-lg"
              style={{
                fontSize: `${20 + noClickCount * 4}px`,
                padding: `${24 + noClickCount * 4}px ${48 + noClickCount * 8}px`
              }}
            >
              TAK! 💖
            </button>
            
            <button
              onClick={moveNoButton}
              className="btn btn-no btn-lg rounded-pill px-4 py-2 fw-semibold shadow position-relative"
              style={noButtonStyle}
            >
              Nie
            </button>
          </div>
          
          {noClickCount > 2 && (
            <p className="text-danger fs-5 mt-4 animate-pulse">
              ❤️ Wiesz, że chcesz powiedzieć TAK! ❤️
            </p>
          )}
          
          <div className="mt-5 d-flex gap-3 justify-content-center fs-2">
            <span className="animate-bounce">🌹</span>
            <span className="animate-bounce" style={{animationDelay: '0.1s'}}>💕</span>
            <span className="animate-bounce" style={{animationDelay: '0.2s'}}>🌹</span>
            <span className="animate-bounce" style={{animationDelay: '0.3s'}}>💕</span>
            <span className="animate-bounce" style={{animationDelay: '0.4s'}}>🌹</span>
          </div>
        </div>
      </div>
    </div>
  );
}
